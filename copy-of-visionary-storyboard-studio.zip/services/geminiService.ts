
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { ImageSize, StoryboardFrame } from "../types";

export const parseScriptIntoScenes = async (scriptText: string): Promise<string[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the following script and extract exactly 4 to 6 key visual scenes for a storyboard. Provide each scene as a detailed visual prompt for an image generator. Return the result as a JSON array of strings. 
    Script:
    ${scriptText}`,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.STRING
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || '[]');
  } catch (e) {
    console.error("Failed to parse script scenes", e);
    return [];
  }
};

export const generateStoryboardImage = async (
  prompt: string, 
  size: ImageSize
): Promise<string> => {
  // Re-initialize to ensure latest API key is used for gemini-3-pro-image-preview
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [{ text: prompt }]
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9",
        imageSize: size
      }
    }
  });

  let imageUrl = '';
  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      imageUrl = `data:image/png;base64,${part.inlineData.data}`;
      break;
    }
  }

  if (!imageUrl) {
    throw new Error("No image data received from API");
  }

  return imageUrl;
};

export const startChat = (systemInstruction: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction
    }
  });
};
