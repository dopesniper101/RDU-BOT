
import React, { useEffect, useState } from 'react';

interface ApiKeyGateProps {
  children: React.ReactNode;
}

// The AIStudio interface is likely already defined in the global scope by the environment.
// We declare it here to ensure TypeScript knows about its structure while matching the expected global type.
declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    aistudio: AIStudio;
  }
}

export const ApiKeyGate: React.FC<ApiKeyGateProps> = ({ children }) => {
  const [isAuthorized, setIsAuthorized] = useState<boolean>(false);
  const [checking, setChecking] = useState<boolean>(true);

  useEffect(() => {
    const checkKey = async () => {
      try {
        const hasKey = await window.aistudio.hasSelectedApiKey();
        setIsAuthorized(hasKey);
      } catch (e) {
        console.error("Error checking API key", e);
      } finally {
        setChecking(false);
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    try {
      await window.aistudio.openSelectKey();
      // Proceed assuming success per instructions to avoid race conditions
      setIsAuthorized(true);
    } catch (e) {
      console.error("Error opening key selector", e);
    }
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <div className="animate-pulse text-indigo-400 text-xl font-semibold">Initializing Studio...</div>
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900 p-4">
        <div className="max-w-md w-full bg-slate-800 border border-slate-700 rounded-2xl p-8 shadow-2xl text-center">
          <div className="w-16 h-16 bg-indigo-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fa-solid fa-key text-indigo-400 text-2xl"></i>
          </div>
          <h2 className="text-2xl font-bold mb-4">API Key Required</h2>
          <p className="text-slate-400 mb-8">
            To use high-quality image generation with Gemini 3 Pro, you must select a valid API key from a paid Google Cloud project.
          </p>
          <button
            onClick={handleSelectKey}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-indigo-500/20"
          >
            Select API Key
          </button>
          <p className="mt-6 text-xs text-slate-500">
            Learn more about <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:underline">Gemini API billing</a>.
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
