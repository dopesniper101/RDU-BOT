
import React, { useState, useCallback } from 'react';
import { ApiKeyGate } from './components/ApiKeyGate';
import { ChatBot } from './components/ChatBot';
import { ImageSize, StoryboardFrame } from './types';
import { parseScriptIntoScenes, generateStoryboardImage } from './services/geminiService';

const App: React.FC = () => {
  const [script, setScript] = useState('');
  const [imageSize, setImageSize] = useState<ImageSize>(ImageSize.ONE_K);
  const [frames, setFrames] = useState<StoryboardFrame[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setScript(content);
    };
    reader.readAsText(file);
  };

  const generateStoryboard = async () => {
    if (!script.trim()) return;
    setIsProcessing(true);
    setFrames([]);
    setProgress(0);

    try {
      // Step 1: Parse scenes
      const scenePrompts = await parseScriptIntoScenes(script);
      const initialFrames: StoryboardFrame[] = scenePrompts.map((p, idx) => ({
        id: `frame-${idx}`,
        description: p,
        status: 'pending'
      }));
      setFrames(initialFrames);

      // Step 2: Generate images sequentially to handle token limits gracefully
      for (let i = 0; i < initialFrames.length; i++) {
        setFrames(current => 
          current.map((f, idx) => idx === i ? { ...f, status: 'generating' } : f)
        );

        try {
          const imageUrl = await generateStoryboardImage(initialFrames[i].description, imageSize);
          setFrames(current => 
            current.map((f, idx) => idx === i ? { ...f, status: 'completed', imageUrl } : f)
          );
        } catch (err: any) {
          console.error(`Failed to generate frame ${i}`, err);
          
          // Handle "Requested entity was not found" error by prompting for key again
          if (err.message?.includes("Requested entity was not found")) {
            await window.aistudio.openSelectKey();
          }

          setFrames(current => 
            current.map((f, idx) => idx === i ? { ...f, status: 'error', errorMessage: 'Generation failed. Check API key.' } : f)
          );
        }
        
        setProgress(Math.round(((i + 1) / initialFrames.length) * 100));
      }
    } catch (error: any) {
      console.error("Storyboard generation failed", error);
      if (error.message?.includes("Requested entity was not found")) {
        await window.aistudio.openSelectKey();
      }
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <ApiKeyGate>
      <div className="min-h-screen pb-20">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-slate-900/80 backdrop-blur-md border-b border-slate-800">
          <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center">
                <i className="fa-solid fa-film text-white"></i>
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">Visionary Studio</h1>
                <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">Storyboard AI</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex bg-slate-800 p-1 rounded-xl border border-slate-700">
                {(Object.values(ImageSize)).map((size) => (
                  <button
                    key={size}
                    onClick={() => setImageSize(size)}
                    disabled={isProcessing}
                    className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                      imageSize === size 
                      ? 'bg-indigo-600 text-white shadow-lg' 
                      : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Script Section */}
          <section className="lg:col-span-4 space-y-6">
            <div className="bg-slate-800/50 border border-slate-700 p-6 rounded-2xl shadow-xl">
              <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
                <i className="fa-solid fa-pen-nib text-indigo-400"></i> Script Input
              </h2>
              <textarea
                value={script}
                onChange={(e) => setScript(e.target.value)}
                placeholder="Paste your screenplay or scene descriptions here..."
                className="w-full h-80 bg-slate-900/50 border border-slate-600 rounded-xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none mb-4 font-mono text-slate-300 leading-relaxed"
              />
              <div className="space-y-4">
                <label className="block">
                  <span className="sr-only">Choose script file</span>
                  <input 
                    type="file" 
                    onChange={handleFileUpload}
                    className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-600/10 file:text-indigo-400 hover:file:bg-indigo-600/20 transition-all cursor-pointer"
                  />
                </label>
                <button
                  onClick={generateStoryboard}
                  disabled={isProcessing || !script.trim()}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-xl transition-all duration-200 transform active:scale-[0.98] flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20"
                >
                  {isProcessing ? (
                    <>
                      <i className="fa-solid fa-spinner animate-spin"></i>
                      Processing... {progress}%
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-wand-magic-sparkles"></i>
                      Generate Storyboard
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="bg-indigo-900/20 border border-indigo-500/20 p-6 rounded-2xl">
              <h3 className="text-sm font-bold text-indigo-300 mb-2 flex items-center gap-2 uppercase tracking-wide">
                <i className="fa-solid fa-circle-info"></i> Pro Tip
              </h3>
              <p className="text-xs text-indigo-200/70 leading-relaxed">
                Gemini 3 Pro Image generation supports cinematic lighting and specific camera angles. Try including terms like "Cinematic lighting", "Wide shot", or "Cyberpunk aesthetic" in your script.
              </p>
            </div>
          </section>

          {/* Result Section */}
          <section className="lg:col-span-8">
            {!isProcessing && frames.length === 0 && (
              <div className="h-[600px] border-2 border-dashed border-slate-700 rounded-2xl flex flex-col items-center justify-center text-slate-500 bg-slate-800/20">
                <i className="fa-solid fa-image text-5xl mb-4 opacity-20"></i>
                <p className="text-lg font-medium">Your visual masterpiece starts here.</p>
                <p className="text-sm">Upload a script to generate your storyboard sequence.</p>
              </div>
            )}

            <div className="space-y-8">
              {frames.map((frame, index) => (
                <div key={frame.id} className="bg-slate-800 border border-slate-700 rounded-3xl overflow-hidden shadow-2xl group transition-all duration-300 hover:border-slate-600">
                  <div className="relative aspect-video bg-slate-900 flex items-center justify-center overflow-hidden">
                    {frame.status === 'completed' && frame.imageUrl ? (
                      <>
                        <img 
                          src={frame.imageUrl} 
                          alt={`Frame ${index + 1}`} 
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                        <div className="absolute top-4 left-4 bg-slate-900/80 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold border border-white/10">
                          SCENE {index + 1}
                        </div>
                        <button 
                          className="absolute bottom-4 right-4 bg-slate-900/80 backdrop-blur-sm w-10 h-10 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:text-indigo-400"
                          onClick={() => window.open(frame.imageUrl, '_blank')}
                        >
                          <i className="fa-solid fa-expand"></i>
                        </button>
                      </>
                    ) : (
                      <div className="flex flex-col items-center gap-4 p-10 text-center">
                        {frame.status === 'generating' ? (
                          <>
                            <div className="w-16 h-16 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
                            <p className="text-indigo-400 font-medium animate-pulse">Rendering high-resolution cinematic view...</p>
                          </>
                        ) : frame.status === 'error' ? (
                          <>
                            <i className="fa-solid fa-circle-exclamation text-red-400 text-3xl"></i>
                            <p className="text-red-400 font-medium">{frame.errorMessage || 'Failed to generate frame'}</p>
                            <button className="text-xs text-slate-400 underline" onClick={generateStoryboard}>Retry Generation</button>
                          </>
                        ) : (
                          <>
                            <i className="fa-solid fa-clock text-slate-700 text-3xl"></i>
                            <p className="text-slate-600 font-medium">Waiting in production queue...</p>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="p-6">
                    <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-2">Director's Note / Scene Description</p>
                    <p className="text-slate-200 leading-relaxed text-sm italic border-l-2 border-indigo-500/30 pl-4">
                      "{frame.description}"
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </main>

        <ChatBot />
      </div>
    </ApiKeyGate>
  );
};

export default App;
